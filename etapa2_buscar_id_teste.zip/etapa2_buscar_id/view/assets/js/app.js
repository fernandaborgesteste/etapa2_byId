document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = '/api/pessoas'; // Ajuste conforme a URL da sua API

    const formPessoa = document.getElementById('formPessoa');
    const pessoaIdInput = document.getElementById('pessoaId');
    const nomeInput = document.getElementById('nome');
    const cpfInput = document.getElementById('cpf');
    const emailInput = document.getElementById('email');
    const idadeInput = document.getElementById('idade');
    const tabelaPessoas = document.getElementById('tabelaPessoas');
    const btnCancelar = document.getElementById('btnCancelar');

    // Função para buscar e exibir todas as pessoas
    async function carregarPessoas() {
        try {
            const response = await fetch(API_BASE_URL);
            const pessoas = await response.json();
            tabelaPessoas.innerHTML = ''; // Limpa a tabela
            pessoas.forEach(pessoa => {
                const row = tabelaPessoas.insertRow();
                row.innerHTML = `
                    <td>${pessoa.id}</td>
                    <td>${pessoa.nome}</td>
                    <td>${pessoa.cpf}</td>
                    <td>${pessoa.email}</td>
                    <td>${pessoa.idade}</td>
                    <td>
                        <button onclick="editarPessoa(${pessoa.id})">Editar</button>
                        <button onclick="excluirPessoa(${pessoa.id})">Excluir</button>
                    </td>
                `;
            });
        } catch (error) {
            console.error('Erro ao carregar pessoas:', error);
        }
    }

    // Função para adicionar ou atualizar uma pessoa
    formPessoa.addEventListener('submit', async (e) => {
        e.preventDefault();
        const pessoa = {
            nome: nomeInput.value,
            cpf: cpfInput.value,
            email: emailInput.value,
            idade: parseInt(idadeInput.value)
        };

        const pessoaId = pessoaIdInput.value;
        let url = API_BASE_URL;
        let method = 'POST';

        if (pessoaId) {
            url = `${API_BASE_URL}/${pessoaId}`;
            method = 'PUT';
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(pessoa)
            });
            if (response.ok) {
                formPessoa.reset();
                pessoaIdInput.value = '';
                carregarPessoas();
            } else {
                console.error('Erro ao salvar pessoa:', await response.json());
            }
        } catch (error) {
            console.error('Erro na requisição:', error);
        }
    });

    // Função para preencher o formulário para edição
    window.editarPessoa = async (id) => {
        try {
            const response = await fetch(`${API_BASE_URL}/${id}`);
            const pessoa = await response.json();
            if (response.ok) {
                pessoaIdInput.value = pessoa.id;
                nomeInput.value = pessoa.nome;
                cpfInput.value = pessoa.cpf;
                emailInput.value = pessoa.email;
                idadeInput.value = pessoa.idade;
            } else {
                console.error('Pessoa não encontrada para edição:', pessoa);
            }
        } catch (error) {
            console.error('Erro ao buscar pessoa para edição:', error);
        }
    };

    // Função para excluir uma pessoa
    window.excluirPessoa = async (id) => {
        if (confirm('Tem certeza que deseja excluir esta pessoa?')) {
            try {
                const response = await fetch(`${API_BASE_URL}/${id}`, {
                    method: 'DELETE'
                });
                if (response.ok) {
                    carregarPessoas();
                } else {
                    console.error('Erro ao excluir pessoa:', await response.json());
                }
            } catch (error) {
                console.error('Erro na requisição de exclusão:', error);
            }
        }
    };

    // Botão Cancelar
    btnCancelar.addEventListener('click', () => {
        formPessoa.reset();
        pessoaIdInput.value = '';
    });

    // Carregar pessoas ao iniciar a página
    carregarPessoas();
});
