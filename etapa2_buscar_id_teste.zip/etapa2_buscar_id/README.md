# Reestruturação do Projeto PHP: MVC com API RESTful

Este documento detalha o plano para reestruturar o projeto PHP existente, implementando um padrão MVC com uma API RESTful para operações CRUD na entidade `Pessoa`. A View será adaptada para consumir esta API.

## 1. Estrutura de Pastas Proposta

```
projeto_php-main/
├── api/                     # Nova pasta para a API RESTful
│   ├── controllers/         # Controladores da API (ex: PessoaController.php)
│   ├── models/              # Modelos da API (ex: Pessoa.php - pode ser compartilhado)
│   ├── dao/                 # Data Access Objects (ex: PessoaDAO.php - pode ser compartilhado)
│   └── index.php            # Ponto de entrada da API, roteamento
├── config/                  # Configurações (ex: conexao.php)
├── public/                  # Nova pasta para arquivos públicos (HTML, CSS, JS)
│   ├── index.html           # Nova View principal (SPA ou com AJAX)
│   └── assets/
│       ├── css/
│       └── js/
├── database.sql             # Script SQL para o banco de dados
└── README.md                # Este arquivo
```

## 2. Componentes e Responsabilidades

### 2.1. API RESTful (`api/`)

*   **`api/index.php`**: Será o ponto de entrada para todas as requisições da API. Responsável por rotear as requisições para os controladores apropriados.
*   **`api/controllers/PessoaController.php`**: Irá lidar com a lógica de negócio para a entidade `Pessoa`. Receberá as requisições HTTP, interagirá com `PessoaDAO` e retornará respostas JSON.
*   **`api/models/Pessoa.php`**: O modelo `Pessoa` existente será reutilizado ou adaptado para representar a entidade `Pessoa`.
*   **`api/dao/PessoaDAO.php`**: O `PessoaDAO` existente será reutilizado para interagir com o banco de dados.

### 2.2. View (`public/`)

*   **`public/index.html`**: Será a nova página principal que carregará a aplicação frontend. Esta página conterá o HTML base e os scripts JavaScript que farão as chamadas AJAX para a API.
*   **`public/assets/js/app.js`**: Conterá a lógica JavaScript para interagir com a API (fazer requisições `GET`, `POST`, `PUT`, `DELETE`), manipular o DOM e exibir os dados para o usuário.
*   **`public/assets/css/style.css`**: Estilos da aplicação.

### 2.3. Configuração (`config/`)

*   **`config/conexao.php`**: Manterá a configuração de conexão com o banco de dados.

## 3. Fluxo de Operações (Exemplo: Listar Pessoas)

1.  O navegador carrega `public/index.html`.
2.  O `app.js` (em `public/assets/js/`) faz uma requisição `GET` para `/api/pessoas`.
3.  O `api/index.php` recebe a requisição e a roteia para `PessoaController`.
4.  `PessoaController` invoca `PessoaDAO->readAll()`.
5.  `PessoaDAO` consulta o banco de dados e retorna uma lista de objetos `Pessoa`.
6.  `PessoaController` converte a lista de `Pessoa` para JSON e a retorna como resposta HTTP.
7.  O `app.js` recebe a resposta JSON, processa os dados e atualiza o DOM para exibir a lista de pessoas.
