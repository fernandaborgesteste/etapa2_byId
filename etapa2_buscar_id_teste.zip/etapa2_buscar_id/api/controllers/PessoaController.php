<?php
require_once __DIR__ . '/../models/pessoa.php';
require_once __DIR__ . '/../dao/pessoaDAO.php';

class PessoaController {
    private $pessoaDAO;

    public function __construct() {
        $this->pessoaDAO = new PessoaDAO();
    }

    public function listarPessoas() {
        $pessoas = $this->pessoaDAO->listarTodos();
        header('Content-Type: application/json');
        echo json_encode($pessoas);
    }

    public function buscarPessoa($id) {
        $pessoa = $this->pessoaDAO->buscarPorId($id);
        header('Content-Type: application/json');
        if ($pessoa) {
            echo json_encode($pessoa);
        } else {
            http_response_code(404);
            echo json_encode(["mensagem" => "Pessoa não encontrada."]);
        }
    }
}
?>
