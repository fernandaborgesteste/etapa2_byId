<?php
require_once __DIR__ . "/../../config/conexao.php";

class PessoaDAO {
    private $conexao;

    public function __construct() {
        $this->conexao = Conexao::getConexao();
    }

    public function buscarPorId($id) {
        $sql = "SELECT * FROM pessoas WHERE id = ?";

        $stmt = $this->conexao->prepare($sql);
        $stmt->execute([$id]);
        $dados = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$dados) return null;
        $p = new Pessoa($dados['nome'], $dados['cpf'], $dados['email'], $dados['idade']);
        $p->setId($dados['id']);
        return $p;
    }

    public function listarTodos() {
        $sql = "SELECT * FROM pessoas ORDER BY nome";
        $stmt = $this->conexao->query($sql);
        $pessoas = [];

        while ($dados = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $p = new Pessoa(
                $dados['nome'],
                $dados['cpf'],
                $dados['email'],
                $dados['idade']
            );

            $p->setId($dados['id']);
            $pessoas[] = $p;
        }
        
        return $pessoas;
    }

}
?>
