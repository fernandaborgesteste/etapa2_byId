<?php
require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/controllers/PessoaController.php";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

$controller = new PessoaController();

$method = $_SERVER["REQUEST_METHOD"];
$requestUri = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$requestUri = str_replace("/api", "", $requestUri); 
$segments = explode("/", trim($requestUri, "/"));

if (isset($segments[0]) && $segments[0] === "pessoas") {
    $id = $segments[1] ?? null;

    switch ($method) {
        case "GET":
            if ($id) {
                $controller->buscarPessoa($id);
            } else {
                $controller->listarPessoas();
            }
            break;
        default:
            http_response_code(405);
            echo json_encode(["mensagem" => "Método não permitido."]);
            break;
    }
} else {
    http_response_code(404);
    echo json_encode(["mensagem" => "Recurso não encontrado."]);
}
?>
