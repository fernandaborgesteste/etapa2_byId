<?php

class Pessoa implements JsonSerializable {
    private $nome;
    private $cpf;
    private $email;
    private $idade;
    private $id;

    public function __construct($nome, $cpf, $email, $idade, $id = null) {
        $this->setNome($nome);
        $this->setCPF($cpf);
        $this->setEmail($email);
        $this->setIdade($idade);
        $this->setId($id);
    }

    public function getNome() { return $this->nome; }
    public function getCPF() { return $this->cpf; }
    public function getEmail() { return $this->email; }
    public function getIdade() { return $this->idade; }
    public function getId() { return $this->id; }

    public function setNome($n) { $this->nome = trim($n); }
    public function setCPF($c) { $this->cpf = trim($c); }
    public function setEmail($e) {
        if (!filter_var($e, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Email inválido");
        }
        $this->email = $e;
    }
    public function setIdade($i) { $this->idade = max(0, (int)$i); }
    public function setId($id) { $this->id = $id; }

    public function jsonSerialize(): mixed {
        return [
            'id' => $this->id,
            'nome' => $this->nome,
            'cpf' => $this->cpf,
            'email' => $this->email,
            'idade' => $this->idade
        ];
    }

    public function __toString() {
        return "{$this->nome} ({$this->cpf}) <{$this->email}> — {$this->idade} anos";
    }
}

?>
